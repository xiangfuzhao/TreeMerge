All the four DLL files are required for running EXE files builded by VC++. 
Just move the four DLL files into the same directory of the EXE files.