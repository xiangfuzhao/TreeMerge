
Step 1. Run 0_MHS_TreeMerge.exe;

Step 2. Click "Browse(MCS).." to select an MCS file like "MCS_LTree_h_*.txt" to test TreeMerge.
