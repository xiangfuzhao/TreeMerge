
Step 1. Run 0_MHS_TreeMerge.exe;

Step 2. Click "Browse(MCS).." to select an MCS family: choose an MCS file like "MCS_2_7*.txt" if you test algorithms BAMHS, BHS-Tree, and DirectMerge algorithm; otherwise, choose an MCS file like "MCS_CBiTree_2_7*.txt" to test TreeMerge and BasicTreeMerge.
