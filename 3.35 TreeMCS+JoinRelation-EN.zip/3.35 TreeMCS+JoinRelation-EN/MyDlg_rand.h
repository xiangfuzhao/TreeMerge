#if !defined(AFX_MYDLG_RAND_H__499E7853_ACD5_4F74_9E13_4404B8DD42C1__INCLUDED_)
#define AFX_MYDLG_RAND_H__499E7853_ACD5_4F74_9E13_4404B8DD42C1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MyDlg_rand.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CMyDlg_rand dialog

class CMyDlg_rand : public CDialog
{
// Construction
public:
	CMyDlg_rand(CWnd* pParent = NULL);   // standard constructor
    BOOL OnInitDialog();
	CString  set_str;
	int* bitVec;
// Dialog Data
	//{{AFX_DATA(CMyDlg_rand)
	enum { IDD = IDD_DIALOG_RAND };
	CComboBox	m_combo2;
	CString	m_inedit2;

	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMyDlg_rand)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CMyDlg_rand)
	afx_msg void OnCreate();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYDLG_RAND_H__499E7853_ACD5_4F74_9E13_4404B8DD42C1__INCLUDED_)
