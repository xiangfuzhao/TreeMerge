// Interface008.h : main header file for the INTERFACE008 application
//

#if !defined(AFX_INTERFACE008_H__94670F44_6AA7_4A5C_AFCD_CC93657AB610__INCLUDED_)
#define AFX_INTERFACE008_H__94670F44_6AA7_4A5C_AFCD_CC93657AB610__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

//��ע��ѡ����ʵ�������䣬��Ҫ���ǲ����ĸ������٣��Ա����ʹ���ڴ�ռ䣡
//const int DefaultSize=100;              //���ϴ�СΪ100�����ڲ�������ʵ��
const int DefaultSize = 3600;           //���ϴ�СΪ3600�����ڲ���ISCAS-85benchmark��·MCSʵ��



/////////////////////////////////////////////////////////////////////////////
// CInterface008App:
// See Interface008.cpp for the implementation of this class
//

class CInterface008App : public CWinApp
{
public:
	CInterface008App();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CInterface008App)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CInterface008App)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_INTERFACE008_H__94670F44_6AA7_4A5C_AFCD_CC93657AB610__INCLUDED_)
