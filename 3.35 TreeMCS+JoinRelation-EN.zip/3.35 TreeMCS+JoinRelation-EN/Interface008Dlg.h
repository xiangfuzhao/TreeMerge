// Interface008Dlg.h : header file
//
#include "afxtempl.h"

#if !defined(AFX_INTERFACE008DLG_H__0110823D_16DF_4998_8D79_A5DF84A9205F__INCLUDED_)
#define AFX_INTERFACE008DLG_H__0110823D_16DF_4998_8D79_A5DF84A9205F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CInterface008Dlg dialog



class CInterface008Dlg : public CDialog
{
// Construction
public:
	CInterface008Dlg(CWnd* pParent = NULL);	// standard constructor
    CList<CString,CString> m_strList;
// Dialog Data
	//{{AFX_DATA(CInterface008Dlg)
	enum { IDD = IDD_INTERFACE008_DIALOG };
	CListBox	m_LinearMCS;
	CListBox	m_gmhsout_inc;
	CListBox	m_dmhsout_inc;
	CListBox	m_CS_Inc;
	CListBox	m_dmhsout;
	CListBox	m_CS;
	CListBox	m_sebout;
	CListBox	m_se2out;
	CListBox	m_esout;
	CListBox	m_bfout;
	CListBox	m_bhsout;
	CListBox	m_list;
	CString	m_bhstime;
	CString	m_bhsnum;
	CString	m_bfnum;
	CString	m_bftime;
	CString	m_estime;
	CString	m_esnum;
	CString	m_se2num;
	CString	m_se2time;
	CString	m_nodec1;
	CString	m_nodec2;
	CString	m_sebtime;
	CString	m_sebnum;
	CString	m_sebnc;
	CString	m_dcstime;
	CString	m_dhssetime;
	CString	m_dhssenodes;
	CString	m_dbhstime;
	CString	m_dbftime;
	CString	m_dsehsdtime;
	CString	m_dsehstime;
	CString	m_dbhsmhsnum;
	CString	m_dbfmhsnum;
	CString	m_dhssemhsnum;
	CString	m_dcsnum;
	CString	m_dsehsdnodes;
	CString	m_dsehsmhsnum;
	CString	m_dsehsnodes;
	CString	m_dsehsdmhsnum;
	CString	m_dcsnum_inc;
	CString	m_dcstime_inc;
	CString	m_MHSECnewnum_inc;
	CString	m_gmhstime_inc;
	CString	m_gmhsnum_inc;
	CString	m_linearYesNo;
	CString	m_NumLinearMCS;
	CString	m_MCSFileName;
	//}}AFX_DATA
	
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CInterface008Dlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CInterface008Dlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnAdd();
	afx_msg void OnDel();
	afx_msg void OnBhsrun();
	afx_msg void OnAmend();
	afx_msg void OnBf();
	afx_msg void OnClearall();
	afx_msg void OnInput();
	afx_msg void OnEs();
	afx_msg void OnSe2();
	afx_msg void OnSeb();
	afx_msg void OnExit();
	afx_msg void OnAboutbox();
	afx_msg void OnButtonRand();
	afx_msg void OnDcs();
	afx_msg void OnDhsse();
	afx_msg void OnDbhs();
	afx_msg void OnDbf();
	afx_msg void OnDsehs();
	afx_msg void OnDsehsd();
	afx_msg void OnDcsInc();
	afx_msg void OnGmhsInc();
	afx_msg void OnCheckLinear();
	afx_msg void OnCheckDMCSLinear();
	afx_msg void OnAutoTestDMCSLinear();
	afx_msg void OnCheckBasicLinear();
	afx_msg void OnCheckDMCSBasicLinear();
	afx_msg void OnAutoTestDMCSBasicLinear();
	afx_msg void OnAutoTestDMCSBasicLinearTimeCost();
	afx_msg void OnInputMCSFileBasicLinearTimeCost();
	afx_msg void OnAutoTestDMCSTree();
	afx_msg void OnCheckDMCSTree();
	afx_msg void OnCheckDMCSTree2();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_INTERFACE008DLG_H__0110823D_16DF_4998_8D79_A5DF84A9205F__INCLUDED_)
