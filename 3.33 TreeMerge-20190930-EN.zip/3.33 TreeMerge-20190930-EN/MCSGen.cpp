#include <stdio.h>

void Gen1MCS(int fenleishu, int lenofset)
{
	for(int i=0; i<fenleishu; i++)
	{
		for(int j = 0; j<= lenofset; j++)
		{
			for(int k = i*(lenofset+1)+j,x=0; x<lenofset; x++)
				printf("%d ", (k+1)<=((lenofset+1)*(i+1))? k++:(k++)%((lenofset+1)*(i+1))+(lenofset+1)*i);
			printf("\n");
		}
	}
}


void main()
{
	int fenleishu = 3; 
	for(int lenofset = 5;lenofset < 8; lenofset ++)
		Gen1MCS(fenleishu, lenofset);

}