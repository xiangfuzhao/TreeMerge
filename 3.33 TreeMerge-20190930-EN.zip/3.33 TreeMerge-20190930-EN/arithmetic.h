#include <assert.h>                    //�쳣����
#include "iostream.h"                  //������
#include "strstrea.h"
//#include "time.h"               
//������
class Set
{
public:
	Set(int MaxSetSize=DefaultSize);   //���캯��
	Set(char * str);
	~Set(){delete[] bitVector;}
	void MakeEmpty(){for(int i=0;i<MaxSize;i++) bitVector[i]=0;}
	int AddMember(const int x);
	int DelMember(const int x);
	void operator =(Set & right);
	void operator +(Set & right);
	void operator *(Set & right);
	void operator -(Set & right);
	int Contains(const int x);
	int SubSet(Set& right);
	int IsEmpty();
	int operator ==(Set & right);
	void show1();
	int * bitVector;
	int MaxSize;
	CString s;
};
Set::Set(int MaxSetSize):MaxSize(MaxSetSize){
	assert(MaxSize>0);
	bitVector=new int [MaxSize];
	assert(bitVector!=0);
	for(int i=0;i<MaxSize;i++) bitVector[i]=0;
}
Set::Set(char * str):MaxSize(DefaultSize){
	assert(MaxSize>0);
	bitVector=new int [MaxSize];
    assert(bitVector!=0);
	for(int i=0;i<MaxSize;i++) bitVector[i]=0;
	int x;
    istrstream ss(str);                //������
	while(!ss.eof())                   //��������
	{
		ss>>x;                         //ȡһ������
        assert(x>=0 && x<MaxSize);
	    bitVector[x]=1;
	}
}
int Set::AddMember(const int x){       //�򼯺��м���Ԫ�أ��ɹ����뷵��1��ԭ���ʹ��ڣ�����0
	assert(x>=0 && x<MaxSize);       
	if(!bitVector[x]){bitVector[x]=1; return 1;}
	return 0;
}
int Set::DelMember(const int x){       //�Ӽ�����ɾ��Ԫ�أ��ɹ�ɾ������1��ԭ���Ͳ����ڣ�����0
	assert(x>=0 && x<MaxSize);
	if(bitVector[x]){bitVector[x]=0; return 1;}
	return 0;
}
void Set::operator =(Set & right){     //��һ����������һ�����ϸ�ֵ
	assert(MaxSize==right.MaxSize);
	for(int i=0;i<MaxSize;i++) bitVector[i]=right.bitVector[i];
}
void Set::operator +(Set & right){     //������
	assert(MaxSize==right.MaxSize);
	for(int i=0;i<MaxSize;i++) bitVector[i]=bitVector[i]||right.bitVector[i];
}
void Set::operator *(Set & right){     //������
	assert(MaxSize==right.MaxSize);
	for(int i=0;i<MaxSize;i++) bitVector[i]=bitVector[i]&&right.bitVector[i];
}
void Set::operator -(Set & right){     //������
	assert(MaxSize==right.MaxSize);
	for(int i=0;i<MaxSize;i++) bitVector[i]=bitVector[i]&&!right.bitVector[i];
}
int  Set::Contains(const int x){       //�ж�x�Ƿ�Ϊ����Ԫ��
	assert(x>=0 && x<MaxSize);
	return bitVector[x];
}
int Set::operator ==(Set & right){     //�ж����������Ƿ����
	assert(MaxSize==right.MaxSize);
	for(int i=0;i<MaxSize;i++)
		if(bitVector[i]!=right.bitVector[i])return 0;
    return 1;
}
int Set::SubSet(Set & right){          //�ü����Ƿ���right���Ӽ�
	assert(MaxSize==right.MaxSize);
	for(int i=0;i<MaxSize;i++)
		if(bitVector[i]&&!right.bitVector[i])return 0;
	return 1;
}
int Set::IsEmpty(){                    //�жϸü����Ƿ�Ϊ��

	for(int i=0;i<DefaultSize;i++)
		if(bitVector[i])
			return 0;
	return 1;
}

void Set::show1(){
	CString s0;
    s="";
	for(int i=0;i<MaxSize;i++)
		if(bitVector[i])
		{
			s0.Empty();
			s0.Format("%d ",i);
			s+=s0;
		};
}
//C�ڵ���
class C_node                           //C�ڵ㣺ÿһ���ڵ����һ������
{
public:
	C_node();
	C_node(char * str);
	C_node(C_node& cn);
	Set S_node;
    C_node * next;
};
C_node::C_node()
{
	next=0;
	S_node=Set(DefaultSize);
}
C_node::C_node(char *str)
{
	next=0;
	S_node=Set(str);
}
C_node::C_node(C_node& cn)
{
	next=0;
	S_node=cn.S_node;
}
//BHS���ڵ�
class B_node                           //BHS���Ľڵ�
{
public:
	B_node();                         
	C_node * C_link;					//C����ָ��һ��C�ڵ���ɵ���������ʾC��
	C_node * M_link;                   //M����ָ��һ��C�ڵ���ɵ���������ʾM��
	Set H_set;                         //H��
	int* Sel;              //һ��������������ѡ����������������x
	int c_size;                        //C���ĸ���
    int Add_C_Set(char * str);         //��C���Ӽ���
	int Add_C_Set(C_node * pcn);

	int Add_C_Set1(char * str);

	int Add_C_Set1(C_node * pcn);
	int Add_M_Set(C_node * pcn);       //��M���Ӽ���
	int Add_M_Set1(C_node * pcn);      
	void Recur();                      //����������M
	void Add_Sel(C_node * &pcn);
	void Sub_Sel(C_node *&pcn);
	void CreateTree();                 //��BHS��
	void Show_M();                     //��ʾM��
	int select();
	int select1();
	B_node * left;                     //������
	B_node * right;                    //������
	CList<CString,CString> Ms_list;
};
B_node::B_node(){
	C_link=0;
	M_link=0;
	c_size=0;
	left=0;
	right=0;
	H_set=Set(DefaultSize);
	Sel=new int[DefaultSize];
	for(int i=0;i<DefaultSize;i++)
	{
		Sel[i]=0;
	}
}
void B_node::Add_Sel(C_node *&pcn){     //�ڼ���ĳ�ڵ�ͬʱ����Sel����������������ʱ�����õ�Sel

	for(int i=0;i<DefaultSize;i++)
		Sel[i]+=pcn->S_node.bitVector[i];
}
void B_node::Sub_Sel(C_node *&pcn){
	for(int i=0;i<DefaultSize;i++)
		Sel[i]-=pcn->S_node.bitVector[i];
}
int B_node::Add_C_Set(char * str){     //�������ַ�������һ��C�ڵ㣬���������C��������ʹ�䱣�ּ�С
	C_node *p,*q,*t,*r=0;
	p=new C_node(str);
    if(C_link==0)                      //C��Ϊ�գ���ֱ�Ӳ���
	{
		C_link=p;
		c_size++;
		Add_Sel(p);
		return 1;
	}
	q=C_link;                          //�����Ϊ�գ���C���и���Ԫ�ؼ��һ��
	r=q->next;
	while(r!=0)
	{
		if(r->S_node.SubSet(p->S_node))//���Ӽ�ʱ��������
		{
			return 0;
		}
		if(p->S_node.SubSet(r->S_node))//p->S_node��r->S_node���Ӽ�ʱ��ɾ��r
		{
			q->next=r->next;
			c_size--;
			Sub_Sel(r);
			t=r;
			r=r->next;
			delete t;
			continue;
		}
		q=q->next;
		r=q->next;
	}
	r=C_link;                          //��C_link���е�һ��Ԫ�ؽ��д���
	if(r->S_node.SubSet(p->S_node))
	{
		return 0;
	}
	if(p->S_node.SubSet(r->S_node))
	{
		C_link=r->next;
		c_size--;
		Sub_Sel(r);
		t=r;
		r=r->next;
		delete t;

	}
    if(c_size==0)                      //�������Ӽ����������C_linkΪ�գ���ֱ�Ӳ���
	{
		C_link=p;
		c_size++;
		Add_Sel(p);
		return 1;		
	}
	else                               //��Ϊ�գ�������β����
	{
		q->next=p;
		c_size++;
		Add_Sel(p);
		return 1;
	}
}
int B_node::Add_C_Set(C_node *pcn){    //��һ��C_node��ָ������һ��C�ڵ㣬������C��
	C_node *p,*q,*r,*t=0;
	p=new C_node(*pcn);
    if(C_link==0)
	{
		C_link=p;
		c_size++;
		Add_Sel(p);
		return 1;
	}
	q=C_link;
	r=q->next;
	while(r!=0)
	{
		if(r->S_node.SubSet(p->S_node))
		{
			return 0;
		}
		if(p->S_node.SubSet(r->S_node))
		{
			q->next=r->next;
			c_size--;
			Sub_Sel(r);
			t=r;
			r=r->next;
			delete t;
			continue;
		}
		q=q->next;
		r=q->next;
	}
	r=C_link;
	if(r->S_node.SubSet(p->S_node))
	{
		return 0;
	}
	if(p->S_node.SubSet(r->S_node))
	{
		C_link=r->next;
		c_size--;
		Sub_Sel(r);
		t=r;
		r=r->next;
		delete t;

	}
    if(c_size==0)
	{
		C_link=p;
		c_size++;
		Add_Sel(p);
		return 1;		
	}
	else
	{
		q->next=p;
		c_size++;
		Add_Sel(p);
		return 1;
	}
}
int B_node::Add_M_Set(C_node * pcn){   //��һ��C_node��ָ������һ��C�ڵ㣬������M��
	C_node *p,*q,*r,*t=0;
	p=new C_node(*pcn);
    if(M_link==0)
	{
		M_link=p;
		return 1;
	}
	q=M_link;
	r=q->next;
	while(r!=0)
	{
		if(r->S_node.SubSet(p->S_node))
		{
			return 0;
		}
		if(p->S_node.SubSet(r->S_node))
		{
			q->next=r->next;
			t=r;
			r=r->next;
			delete t;
			continue;
		}
		q=q->next;
		r=q->next;
	}
	r=M_link;
	if(r->S_node.SubSet(p->S_node))
	{
		return 0;
	}
	if(p->S_node.SubSet(r->S_node))
	{
		M_link=r->next;
		t=r;
		r=r->next;
		delete t;

	}
    if(M_link==0)
	{
		M_link=p;
		return 1;		
	}
	else
	{
		q->next=p;
		return 1;
	}
}


int B_node::Add_C_Set1(char * str){  //��C���ӽڵ㣬�����ؼ���Ƿ��а�����ϵ
	C_node *p,*q;
	p=new C_node(str);
    if(C_link==0)
	{
		C_link=p;
		c_size++;
		Add_Sel(p);
		return 1;
	}
    q=C_link;
	while(q->next!=0)
	{
		q=q->next;
	}
	q->next=p;
	c_size++;
	Add_Sel(p);
	return 1;
}
int B_node::Add_C_Set1(C_node * pcn){  //��C���ӽڵ㣬�����ؼ���Ƿ��а�����ϵ
	C_node *p,*q;
	p=new C_node(*pcn);
    if(C_link==0)
	{
		C_link=p;
		c_size++;
		Add_Sel(p);
		return 1;
	}
    q=C_link;
	while(q->next!=0)
	{
		q=q->next;
	}
	q->next=p;
	c_size++;
	Add_Sel(p);
	return 1;
}



int B_node::Add_M_Set1(C_node * pcn){  //��M���ӽڵ㣬�����ؼ���Ƿ��а�����ϵ
	C_node *p,*q;
	p=new C_node(*pcn);
    if(M_link==0)
	{
		M_link=p;
		return 1;
	}
    q=M_link;
	while(q->next!=0)
	{
		q=q->next;
	}
	q->next=p;
	return 1;
}
int B_node::select(){                  //�Ӽ��ϴ���ѡһ��Ԫ�أ�ѡ��һ����͵ĵ�һ��Ԫ��

	C_node *p;
	p=C_link;
	while(p!=0)
	{
		for(int i=0;i<DefaultSize;i++)
			if(p->S_node.bitVector[i])
			{
				return i;
			};
        p=p->next; 
	}
	return -1;
}
int B_node::select1()                  //�Ӽ��ϴ���ѡһ��Ԫ�أ�ѡ���������г��ִ�������Ԫ��
{
	int x,y;
	x=0;
	y=Sel[x];                          //Sel��B_node�ĳ�Ա����
	for(int i=1;i<DefaultSize;i++)    
	{
		if(y<Sel[i])
		{
			y=Sel[i];
			x=i;
		}
	}
    if(x==0&&Sel[0]==0)
		return -1;
	return x;
}

void B_node::CreateTree(){             //�ݹ齨��BHS��
	int a;
	B_node * lc,*rc;
	C_node * p,*q;
	a=select1();                       //ѡ����ʵ�a
	if((a>=0)&&(a<DefaultSize))
	{
	    lc=new B_node();
	    rc=new B_node();
	    p=C_link;
		while(p!=0)
		{
			q=new C_node(*p);
			if(q->S_node.Contains(a))  //����a�ļ���ɾȥԪ��a���ڲ���������
			{
				q->S_node.DelMember(a);
				lc->Add_C_Set1(q);
				//lc->Add_C_Set(q);

			}
			else                       //������a�ļ��ϣ�ֱ�Ӳ���������
			{
				rc->Add_C_Set1(q);
				//rc->Add_C_Set(q);
			}
			delete q;
			p=p->next;
		}
		lc->H_set.AddMember(a);        //��a������������H��
		left=lc;
		left->CreateTree();            //�ݹ齨��������
		if(rc->c_size>0)               //�鿴�Ƿ��б�Ҫ����������
		{
			right=rc;
			right->CreateTree();
		}
		else
			right=0;
	}
}
void B_node::Recur(){                  //�Ե�������MHS
	C_node * p,*q,*lt,*rt;	
	if((left==0)&&(right==0))          //������ΪҶ�ڵ㣬��M=H
	{
		p=new C_node();
		p->S_node=H_set;
        Add_M_Set(p);
		delete p;
	}
	else                               
	{
		if((right==0)&&(left!=0))      //������������������
		{
			left->Recur();             //�������������M
			if(!H_set.IsEmpty())       //��H��Ϊ��Ҳ�������M
			{
				p=new C_node();
                p->S_node=H_set;
				Add_M_Set(p);
				delete p;
			}
			q=left->M_link;            //����������M��������M
			while(q!=0)
			{
				Add_M_Set(q);
				q=q->next;
			}
		}
		else                           //��������������������
		{
			left->Recur();             //�������������M
			right->Recur();
			if(!H_set.IsEmpty())       //�Ƚ�H����
			{
				p=new C_node();
                p->S_node=H_set;
				Add_M_Set(p);
				delete p;
			}
			lt=left->M_link;
			while(lt!=0)               //��mr��ml���루����mr����Mr��ml����Ml��
			{
				rt=right->M_link;
				while(rt!=0)
				{
					p=new C_node();
					p->S_node=lt->S_node;
					(p->S_node)+(rt->S_node);
					Add_M_Set(p);
					delete p;
					rt=rt->next;
				}
				lt=lt->next;
			}
		}
	}
}

void B_node::Show_M(){                 //��ʾM��
	CString s;
	C_node *p;
	p=M_link;
	while(p!=0)                        
	{
		(p->S_node).show1();
		s=(p->S_node).s;
		Ms_list.AddHead(s);
		p=p->next;
	}
}
//��������ʽ��
class BF                               //����ʽ
{
public:
	int MaxSize;                       //����ʽ�����ֵķ�Χ
	int *bitVector;
	BF* next;
	BF();
	~BF(){delete[]bitVector;}
	BF(char* str);
	BF(BF & b);
	int Mul_Word(int x);               //����ʽ����������ĳ����
	int Contains(int x);               //����ʽ���Ƿ���x;
	int Del_Word(int x);               //�ӵ���ʽ��ɾȥĳ����
	int SubSet(BF & right);            //right�������Ƿ����this������
	void Show();
	CString s;
};
BF::BF():MaxSize(DefaultSize){         //���캯��������һ�������κ����ֵĵ���ʽ
	assert(MaxSize>0);
	bitVector=new int[MaxSize];
	assert(bitVector!=0);
	for(int i=0;i<MaxSize;i++) bitVector[i]=0;
	next=0;
}
BF::BF(char* str):MaxSize(DefaultSize){//���캯�����������ַ���str�����ĵ���ʽ
	assert(MaxSize>0);
	bitVector=new int[MaxSize];
	assert(bitVector!=0);
	for(int i=0;i<MaxSize;i++)bitVector[i]=0;
	next=0;
	int x;
	istrstream ss(str);
	while(!ss.eof())
	{
		ss>>x;
		assert(x>=0 && x<MaxSize);
		bitVector[x]=1;
	}
}
BF::BF(BF & b){                        //�������캯��
	next=0;
	MaxSize=b.MaxSize;
	bitVector=new int[MaxSize];
	for(int i=0;i<MaxSize;i++)
		bitVector[i]=b.bitVector[i];
}
int BF::Mul_Word(int x){               //������x���뵥��ʽ�У���ǰ����ʽ���и������򷵻�0�����򷵻�1
	assert(x>=0 && x<MaxSize);
	if(!bitVector[x]){bitVector[x]=1;return 1;}
	return 0;
}
int BF::Contains(int x){               //����ʽ�Ƿ��������x
	assert(x>=0 && x<MaxSize);
	return bitVector[x];
}
int BF::Del_Word(int x){               //�ӵ���ʽ��ɾ������x����ǰ����ʽ���и������򷵻�1�����򷵻�0
	assert(x>=0 && x<MaxSize);
	if(bitVector[x]){bitVector[x]=0; return 1;}
	return 0;
}
int BF::SubSet(BF & right){            //�ü����Ƿ���right���Ӽ�
	assert(MaxSize==right.MaxSize);
	for(int i=0;i<MaxSize;i++)
		if(bitVector[i]&&!right.bitVector[i])return 0;
	return 1;
}
void BF::Show(){
	CString s0;
    s="";
	for(int i=0;i<MaxSize;i++)
		if(bitVector[i])
		{
			s0.Empty();
			s0.Format("%d ",i);
			s+=s0;
		};
}
//��������ʽ��
class BF_list                          //����ʽ
{
public:
	BF* head;
	BF* rear;
	BF_list();
	void Add_Bf(char* str);            //�����ʽ�����ӵ���ʽ������ʽ���ַ�������
	void Add_Bf(BF* pbf);              //�����ʽ�����ӵ���ʽ������ʽ�ɵ���ʽָ�����
	int  Add_Bf1(BF* pbf);             //�����ʽ�����ӵ���ʽ������ʽ�ɵ���ʽָ���������������ʽ���Ƿ����໥�����ĵ���ʽ
	BF* Del_Bf();                      //�ӱ���ʽ��ɾ������ʽ
	void Mul(int x);                   //������ʽ�е�ÿһ���������x
	void Mul1(int x);                  //������ʽ�е�ÿһ���������x
	void Combine(BF_list* bfp);        //������ʽbfp�е�ÿһ�������ǰ����ʽ
	void Negation();                   //����ʽȡ��
	void ShowSets();                   //��ʾ����ʽ������
	void ForShort();                   //������ʽ����
	CList<CString,CString> Bfs_list;
};
BF_list::BF_list(){
	head=0;
	rear=0; 
}
void BF_list::Add_Bf(char* str){
	BF* p=new BF(str);

	p->next = NULL;

	if(head==0)
	{
		head=p;
		rear=p;
	}
	else
	{
		rear->next=p;
		rear=rear->next;
	}
}
void BF_list::Add_Bf(BF* pbf){
	BF* p=new BF(*pbf);

	p->next = NULL;

	if(head==0)
	{
		head=p;
		rear=p;
	}
	else
	{
		rear->next=p;
		rear=rear->next;
	}
}
int BF_list::Add_Bf1(BF* pbf){
	BF *q,*t,*r;

	pbf->next = NULL;
	
	if(head==0)
	{
		head=pbf;
		rear=pbf;
		rear->next=0;
		return 1;
	}
	q=head;
	r=q->next;
	while(r!=0)
	{
		if(r->SubSet(*pbf))
		{
			return 0;
		}
		if(pbf->SubSet(*r))
		{
			q->next=r->next;
			t=r;
			r=r->next;
			delete t;
			continue;
		}
		q=q->next;
		r=q->next;
	}
	r=head;
	if(r->SubSet(*pbf))
	{
		return 0;
	}
	if(pbf->SubSet(*r))
	{
		head=r->next;
		t=r;
		r=r->next;
		delete t;
	}
	if(head==0)
	{
		head=pbf;
		rear=pbf;
		rear->next=0;
		return 1;
	}
	else
	{
		q->next=pbf;
		rear=pbf;
		rear->next=0;
		return 1;
	}
}

void BF_list::Combine(BF_list* bfp){

	if(head==0)
	{
		head=bfp->head;
		rear=bfp->rear;
	}
	else
	{
		rear->next=bfp->head;
	    rear=bfp->rear;
	    bfp->head=0;

		bfp->rear->next = NULL;

	    bfp->rear=0;
	}
}
void BF_list::Mul(int x){
	BF *p;
	for(p=head;p!=0;p=p->next)
	{
		p->Mul_Word(x);
	}
}
void BF_list::Mul1(int x){
	BF *p;
	if(head==0)
	{
		p=new BF();

		p->next = NULL;

		p->Mul_Word(x);
		head=p;
		rear=p;
	}
	else
	{
		for(p=head;p!=0;p=p->next)
		{
			p->Mul_Word(x);
		}
	}
}
void BF_list::ShowSets(){
	CString s;
	BF *p;
	p=head;
	while(p!=0)                        
	{
		p->Show();
		s=p->s;
		Bfs_list.AddHead(s);
		p=p->next;
	}
}
void BF_list::Negation(){
	BF *p,*q,*r,*s,*ph,*pr;
	int i;
	if(head!=0)
	{
		if(head==rear)                 //ֻ��һ��
		{
			p=head;
			ph=0;
			pr=0;
			for(i=0;i<DefaultSize;i++)
				if(p->bitVector[i])
				{
					q=new BF();

					q->next = NULL;

					q->bitVector[i]=1;
					if(ph==0)
					{
						ph=q;
						pr=q;
					}
					else
					{
						pr->next=q;
						pr=q;
					}
				};
			head=ph;
			rear=pr;
			delete p;
		}
		else                           //of if(head==rear) ��ֻ��һ��
		{
			int* Sel;
			int t_size,e_size,single,se;
			Sel=new int[DefaultSize];
			for(i=0;i<DefaultSize;i++)
				Sel[i]=0;
			t_size=0;                  //����ʽ�ж���ĸ���
			single=0;                  //��ʾ�Ƿ��ǵ�����
			q=0;
			for(p=head;p!=0;p=p->next)
			{
				t_size++;
				e_size=0;              //ÿ�����������ֵĸ���
				for(i=0;i<DefaultSize;i++)
				{
					if(p->bitVector[i])
					{
						e_size++;
						Sel[i]++;
					}
				}
				if(e_size==1)
				{
					single++;
					q=p;
					for(i=0;i<DefaultSize;i++)
					{
						if(p->bitVector[i])
							se=i;
					}
				}
			}// of for
			int y;
            int Max_per=0;
			y=Sel[0];
	        for(i=1;i<DefaultSize;i++)
			{				
				if(y<Sel[i])
				{
					Max_per=i;
					y=Sel[i];
				}
			}
			if(single)                 //�е�����
			{
				if(Sel[Max_per]==t_size) // ÿ�������eO
				{
					ph=new BF();

					ph->next = NULL;

					ph->Mul_Word(Max_per);
					r=head;
					head=ph;
					rear=ph;
					if(r!=0)
					{
						while(r->next!=0)
						{
							s=r->next;
							delete r;
							r=s;
						}
						delete r;
					}
				}
				else                  //����ÿ���
				{
					BF_list * blp1=new BF_list();
					for(p=head;p!=0;p=p->next)
					{
						if(!p->bitVector[se])
							blp1->Add_Bf(p);
					}
					blp1->Negation();
					blp1->Mul1(se);
					r=head;
					head=blp1->head;
					rear=blp1->rear;
					blp1->head=0;
					blp1->rear=0;
					delete blp1;
					if(r!=0)
					{
						while(r->next!=0)
						{
							s=r->next;
							delete r;
							r=s;
						}
						delete r;
					}
				}
			}
			else  //of if(single)
			{
				BF_list * blp1=new BF_list();
				BF_list * blp2=new BF_list();
				for(p=head;p!=0;p=p->next)
				{
					if(p->bitVector[Max_per])  //�����e
					{
						p->Del_Word(Max_per);
						blp2->Add_Bf(p);
					}
					else
					{
						blp1->Add_Bf(p);
						blp2->Add_Bf(p);
					}
				}
				blp1->Negation();
				blp2->Negation();
				blp1->Mul1(Max_per);
				blp1->Combine(blp2);
				ph=head;
				r=head;
				if(r!=0)
				{
					while(r->next!=0)
					{
						s=r->next;
						delete r;
						r=s;
					}
					delete r;
				}
				head=blp1->head;
				rear=blp1->rear;
				blp1->head=0;
				blp1->rear=0;
				blp2->head=0;
				blp2->rear=0;
				delete blp1;
				delete blp2;				
			} //of else
		}   //of else  if(head==rear) 
	}
}
void BF_list::ForShort(){
	BF *r,*p=head;
	BF_list *bl1;
	bl1=new BF_list();
    while(p!=0)
	{
		r=p->next;
		p->next=0;
		bl1->Add_Bf1(p);
		p=r;
	}
	head=bl1->head;
	rear=bl1->rear;
	bl1->head=0;
	bl1->rear=0;
	delete bl1;
}

class S_node
{
public:
	int* bitVector;
	S_node* next;
	S_node();
	S_node(char* str);

/*
//20161223 for Tree_Merge only
	S_node_TreeMerge(char * str);
*/

};
S_node::S_node(){
	bitVector=new int [DefaultSize];
	for(int i=0;i<DefaultSize;i++) bitVector[i]=0;
	next=0;
}
S_node::S_node(char* str){
	bitVector=new int [DefaultSize];
	for(int i=0;i<DefaultSize;i++) bitVector[i]=0;
	next=0;
	int x;
    istrstream ss(str);                //������
	while(!ss.eof())                   //��������
	{
		ss>>x;                         //ȡһ������
        assert(x>=0 && x<DefaultSize);
	    bitVector[x]=1;
	}
}

/*
//20161223 for Tree_Merge only
S_node_TreeMerge(char * str){	//��str��ʾtree�ļ��е�һ����Ϣ��ǰ3����ֵ�ֱ�Ϊ�����ڵ��˫�׽ڵ㡢ST2�Ŀ�ʼ��š�ST3�Ŀ�ʼ��ţ��������Ϊ�ýڵ��set
	bitVector=new int [DefaultSize];
	for(int i=0;i<DefaultSize;i++) bitVector[i]=0;
	next=0;
	int x;
    istrstream ss(str);                //������
	int count = 0;						//���ڼ������ǵ�3ʱ�˳�
	while(!ss.eof())                   //��������
	{
		ss>>x;                         //ȡһ������
        assert(x>=0 && x<DefaultSize);
	    bitVector[x]=1;
	}
}
*/
	
	
	
class input_list
{
public:
	int Count;                         //��ͻ���ĸ���
	input_list();
	S_node* s_point;
	int last;                          //���һ�������Ԫ��
	int * exist;                       //�����Ԫ�� �������Ĵ���
	void Insert_S(char* str);
	void Insert_S(S_node *q);
	~input_list();
};
input_list::input_list(){
	Count=0;
	s_point=0;
	last=-1;
	exist=new int[DefaultSize];
	for(int i=0;i<DefaultSize;i++)
	{
		exist[i]=0;
	}
}
input_list::~input_list(){
	S_node *p,*q;
	p=s_point;
	if(p!=0)
	{
		while(p->next!=0)
		{
			q=p->next;
			delete p;
			p=q;
		}
		delete p;
	}
	delete exist;
}
void input_list::Insert_S(char* str){//ͨ�����봮���ɹ���һ���µ�input_list����
	S_node *p,*q;
    q=new S_node(str);
	if(s_point==0)
	{
		s_point=q;
	}
	else
	{
		p=s_point;
		while(p->next!=0)
		{
			p=p->next;
		}
		p->next=q;
	}
	Count++;
	for(int i=0;i<DefaultSize;i++)
		exist[i]+=q->bitVector[i];
	for(i=last+1;i<DefaultSize;i++)
	{
		if(q->bitVector[i])
		{
			last=i;
		}
	}
}

void input_list::Insert_S(S_node *q){//ͨ�����뼯�Ͻڵ㼴�ɹ���һ���µ�input_list����
	S_node *p;
  	if(s_point==0)
	{
		s_point=q;
	}
	else
	{
		p=s_point;
		while(p->next!=0)
		{
			p=p->next;
		}
		p->next=q;
	}
	Count++;
	for(int i=0;i<DefaultSize;i++)
		exist[i]+=q->bitVector[i];
	for(i=last+1;i<DefaultSize;i++)
	{
		if(q->bitVector[i])
		{
			last=i;
		}
	}
}




class element
{
public:
	int* *pn;                          //ÿ��Ԫ������������Ĺ���
	int Cs;                            //��������ĸ���
	element(int Count);
	element(input_list* il);
};
element::element(int Count){
	int i,j;
	Cs=Count;
	pn=new int*[DefaultSize];
	for(i=0;i<DefaultSize;i++)
		pn[i]=new int[Count];
	for(i=0;i<DefaultSize;i++)
		for(j=0;j<Count;j++)
			pn[i][j]=0;
}
element::element(input_list* il){
	int i,j;
	Cs=il->Count;
	pn=new int*[DefaultSize];
	for(i=0;i<DefaultSize;i++)
		pn[i]=new int[Cs];
    S_node* p;
	for(p=il->s_point,i=0;p!=0;p=p->next,i++)
	{
		for(j=0;j<DefaultSize;j++)
		{
			pn[j][i]=p->bitVector[j];
		}
	}
}
class Node{
public:
	Node(int x);
	Node(Node &n);
	int Value;
	Node* next;
};
Node::Node(int x){
	Value=x;
	next=0;
}
Node::Node(Node &n)
{
	Value=n.Value;
	next=0;
}
class NYH_HSSE{
public:
	NYH_HSSE();
	NYH_HSSE(NYH_HSSE &li);
	Node* head;
	void AddMember(int Size);
	int DeleteMember(int x);
};
NYH_HSSE::NYH_HSSE(){
	head=0;
}

NYH_HSSE::NYH_HSSE(NYH_HSSE &li)
{
	Node *p,*q,*r;
	q=li.head;
	if(q!=0)
	{
		p=new Node(*q);
	    head=p;
		r=head;
		while(q->next!=0)
		{
			p=new Node(*(q->next));
			r->next=p;
			r=p;
			q=q->next;
		}
	}
	else
	{
		head=0;
	}
}
void NYH_HSSE::AddMember(int Size)
{
	if(Size>0)
	{	
		Node* p,*q;
	    q=0;
	    for(int i=Size-1;i>=0;i--)
		{
			p=new Node(i);
			p->next=q;
			q=p;
		}
		head=q;
	}
}
int NYH_HSSE::DeleteMember(int x){
	Node *p,*q;
	p=head;
	if(p==0)
		return 0;
	else
	{
		if(p->Value==x)
		{
			head=p->next;
			delete p;
			return 1;
		}
		else
		{
			while(p->next!=0)
			{
				if(p->next->Value==x)
				{
					q=p->next;
					p->next=q->next;
					delete q;
					return 1;
				}
				else
				{
					if(p->next->Value<x)
					{
						p=p->next;
					}
					else
					{
						return 0;
					}
				}
			}
		}
		if(p->Value==x)
			return 1;
		else 
			return 0;
	}
}
class enumSetNode
{
public:
	int* bitVector;
	enumSetNode* next;
	//int* sign_cs;                      //�������
	NYH_HSSE* sign;
	//int Rcount;                        //��ؼ��ϸ���
	int Cs;                            //���뼯de����
	int last_e;
	int IsHS();
	void AddMember(int x,element* &e);
	CString Show();
	int SubSet(enumSetNode & right);   //�ü����Ƿ���right���Ӽ�
	enumSetNode(int Count);
	enumSetNode(enumSetNode& esn);
};
enumSetNode::enumSetNode(int Count)
{
	bitVector=new int[DefaultSize];
	for(int i=0;i<DefaultSize;i++)
		bitVector[i]=0;
	next=0;
    Cs=Count;
    sign=new NYH_HSSE();
	sign->AddMember(Cs);
	last_e=-1;
}
enumSetNode::enumSetNode(enumSetNode& esn)
{
	bitVector=new int[DefaultSize];
	for(int i=0;i<DefaultSize;i++)
		bitVector[i]=esn.bitVector[i];
	next=0;
	Cs=esn.Cs;
    sign=new NYH_HSSE(* (esn.sign));
	last_e=esn.last_e;
}
int enumSetNode::SubSet(enumSetNode & right){
	for(int i=0;i<DefaultSize;i++)
		if(bitVector[i]&&!right.bitVector[i])return 0;
	return 1;
}
void enumSetNode::AddMember(int x,element*&e)
{
	bitVector[x]=1;
	int i,m=0;
	for(i=0;i<Cs;i++)
	{
		if(e->pn[x][i])
		{
			sign->DeleteMember(i);
		}
	}
	last_e=x;
}

int enumSetNode::IsHS()
{
	if(sign->head==0)
	{
		return 1;
	}
    return 0;
}
CString enumSetNode::Show(){
	CString s="";
	CString s0;
	for(int i=0;i<DefaultSize;i++)
		if(bitVector[i])
		{
			s0.Empty();
			s0.Format("%d ",i);
			s+=s0;
		};
		return s;
}
class enumSetList
{
public:
	enumSetNode* head;
	enumSetNode* rear;
	enumSetList();
	int IsEmpty();
	void AddRear_Node(enumSetNode*&eSN);
    enumSetNode* DelHead();
};

enumSetList::enumSetList(){
	head=0;
	rear=0;
}
int enumSetList::IsEmpty(){
	if(head==0)
		return 1;
	else
		return 0;
}
void enumSetList::AddRear_Node(enumSetNode*&eSN){
	if(rear==0)
	{
		head=eSN;
		rear=eSN;
		rear->next=0;
	}
	else
	{
		rear->next=eSN;
		rear=rear->next;
		rear->next=0;
	}
}
enumSetNode* enumSetList::DelHead(){
	if(head==0)
	{
		return 0;
	}
	else
	{
		enumSetNode* p;
		p=head;
		head=head->next;
		if(head==0)
		{
			rear=0;
		}
		return p;
	}
}

class ResultList{
public:
	enumSetNode* R_link;
	CList<CString,CString> es_list;
	ResultList();
	int Add_Rset(enumSetNode* &esn);
	void Show_All();
	~ResultList();
};
ResultList::ResultList(){
	R_link=0;
}
ResultList::~ResultList(){
	enumSetNode *p,*q;
	p=R_link;
	if(p!=NULL)
	{
		while(p->next != NULL)
		{
			q=p->next;
			delete p;
			p=q;
		}
		delete p;
	}
//	R_link = NULL;
}
void ResultList::Show_All(){
	enumSetNode* p;
	es_list.RemoveAll();
	for(p=R_link;p!=0;p=p->next)
	{
		es_list.AddHead(p->Show());
	}
}
int ResultList::Add_Rset(enumSetNode*&esn){
	if(R_link==0)                      //��Ϊ��
	{
		R_link=esn;
		esn->next=0;
		return 1;
	}
	else
	{
		enumSetNode* p;
		for(p=R_link;p->next!=0;p=p->next)
		{
			if(p->SubSet(*esn))        //��������иü��ϵ��Ӽ�
			{
				delete esn;
				return 0;
			}
		}
		if(p->SubSet(*esn))
		{
			delete esn;
			return 0;
		}
		p->next=esn;
		esn->next=0;
        return 1;
	}
}
	
void HSSE_tree(input_list*&il,ResultList*&pHS,int& node_count){
	int i;
	node_count=1;
	enumSetNode* p,*q;
	element *e=new element(il);

	enumSetList* eSL=new enumSetList();
	enumSetList* nEL=new enumSetList();

	for(i=0;i<DefaultSize;i++)         //��ʼ
	{
		if(il->exist[i])
		{
			p=new enumSetNode(il->Count);
			node_count++;
			p->AddMember(i,e);
			eSL->AddRear_Node(p);
		}
	}
	while(1)
	{
		for(p=eSL->DelHead();p!=0;p=eSL->DelHead())
		{
			if(p->IsHS())              //hitting set
            {
				pHS->Add_Rset(p);      //��������
            }
			else
			{
				if(p->bitVector[il->last])//�����������к�����ĩԪ��
				{
					delete p;
				}
				else                   //������չ
				{
					nEL->AddRear_Node(p);
				}
			}
		}
        if(nEL->head==0)
			break;
		for(p=nEL->DelHead();p!=0;p=nEL->DelHead())
		{
			for(i=p->last_e+1;i<=il->last;i++)
			{
				if(il->exist[i])
				{
					q=new enumSetNode(*p);
					node_count++;
					q->AddMember(i,e);
					eSL->AddRear_Node(q);
				}
			}
			delete p;
		}
	}	
}
#pragma pack(1)
class S_node2                           //�������Ľڵ�
{
public:
	int* bitVector;
	S_node2* next;
	S_node2();
	S_node2(char* str);
	int Max;
};
#pragma pack()
S_node2::S_node2(){
	bitVector=new int [DefaultSize];
	for(int i=0;i<DefaultSize;i++) bitVector[i]=0;
	next=0;
	Max=0;
}
S_node2::S_node2(char* str){
	bitVector=new int [DefaultSize];
	for(int i=0;i<DefaultSize;i++) bitVector[i]=0;
	next=0;
	int x;
    istrstream ss(str);                //������
	while(!ss.eof())                   //��������
	{
		ss>>x;                         //ȡһ������
        assert(x>=0 && x<DefaultSize);
		if(x>Max)
		{
			Max=x;
		}
	    bitVector[x]=1;
	}
}
#pragma pack(1)
class input_list2
{
public:
	int Count;                         //��ͻ���ĸ���
	input_list2();
	S_node2* s_point;
	int last;                          //���һ�������Ԫ��
	int * exist;                       //�����Ԫ�� �������Ķ�����
	void Insert_S(char* str);

	void Insert_S(S_node2 * q);
};
#pragma pack()
input_list2::input_list2()
{
	Count=0;
	s_point=0;
	last=-1;
	exist=new int[DefaultSize];
	for(int i=0;i<DefaultSize;i++)
	{
		exist[i]=0;
	}
}
void input_list2::Insert_S(char* str)
{
	S_node2 *p,*q;
    q=new S_node2(str);
	if(s_point==0)
	{
		s_point=q;
	}
	else
	{
		p=s_point;
		while(p->next!=0)
		{
			p=p->next;
		}
		p->next=q;
	}
	Count++;
	for(int i=0;i<DefaultSize;i++)
		exist[i]+=q->bitVector[i];
	for(i=last+1;i<DefaultSize;i++)
	{
		if(q->bitVector[i])
		{
			last=i;
		}
	}
}

void input_list2::Insert_S(S_node2 *q)
{
	S_node2 *p;
 //   q=new S_node2(str);
	if(s_point==0)
	{
		s_point=q;
	}
	else
	{
		p=s_point;
		while(p->next!=0)
		{
			p=p->next;
		}
		p->next=q;
	}
	Count++;
	for(int i=0;i<DefaultSize;i++)
		exist[i]+=q->bitVector[i];
	for(i=last+1;i<DefaultSize;i++)
	{
		if(q->bitVector[i])
		{
			last=i;
		}
	}
}

#pragma pack(1)
class element2
{
public:
	int* *pn;                          //ÿ��Ԫ������������Ĺ���
	int Cs;                            //��������ĸ���
	element2(int Count);
	element2(input_list2* il);
	int* Max;
};
#pragma pack()
element2::element2(int Count){
	int i,j;
	Cs=Count;
	pn=new int*[DefaultSize];
	for(i=0;i<DefaultSize;i++)
		pn[i]=new int[Count];
	Max=new int[Count];
	for(i=0;i<DefaultSize;i++)
		for(j=0;j<Count;j++)
			pn[i][j]=0;
	for(j=0;j<Count;j++)
		Max[j]=DefaultSize-1;
}
element2::element2(input_list2* il){
	int i,j;
	Cs=il->Count;
	pn=new int*[DefaultSize];
	for(i=0;i<DefaultSize;i++)
		pn[i]=new int[Cs];
	Max=new int[Cs];
    S_node2* p;
	for(p=il->s_point,i=0;p!=0;p=p->next,i++)
	{
		for(j=0;j<DefaultSize;j++)
		{
			pn[j][i]=p->bitVector[j];
		}
		Max[i]=p->Max;
	}
}
#pragma pack(1)
class Node2{
public:
	Node2(int x);
	Node2(Node2 &n);
	int Value;
	Node2* next;
};
#pragma pack()
Node2::Node2(int x){
	Value=x;
	next=0;
}
Node2::Node2(Node2 &n)
{
	Value=n.Value;
	next=0;
}
#pragma pack(1)
class NYH_SE{
public:
	NYH_SE();
	NYH_SE(NYH_SE &li);
	Node2* head;
	void AddMember(int Size);
	int DeleteMember(int x);
};
#pragma pack()
NYH_SE::NYH_SE(){
	head=0;
}

NYH_SE::NYH_SE(NYH_SE &li)
{
	Node2 *p,*q,*r;
	q=li.head;
	if(q!=0)
	{
		p=new Node2(*q);
	    head=p;
		r=head;
		while(q->next!=0)
		{
			p=new Node2(*(q->next));
			r->next=p;
			r=p;
			q=q->next;
		}
	}
	else
		head=0;
}
void NYH_SE::AddMember(int Size)
{
	if(Size>0)
	{	
		Node2* p,*q;
	    q=0;
	    for(int i=Size-1;i>=0;i--)
		{
			p=new Node2(i);
			p->next=q;
			q=p;
		}
		head=q;
	}
}
int NYH_SE::DeleteMember(int x){
	Node2 *p,*q;
	p=head;
	if(p==0)
		return 0;
	else
	{
		if(p->Value==x)
		{
			head=p->next;
			delete p;
			return 1;
		}
		else
		{
			while(p->next!=0)
			{
				if(p->next->Value==x)
				{
					q=p->next;
					p->next=q->next;
					delete q;
					return 1;
				}
				else
				{
					if(p->next->Value<x)
					{
						p=p->next;
					}
					else
					{
						return 0;
					}
				}
			}
		}
		if(p->Value==x)
			return 1;
		else 
			return 0;
	}
}
#pragma pack(1)
class enumSetNode2
{
public:
	int* bitVector;
	enumSetNode2* next;
	//int* sign_cs;                      //�������
	NYH_SE * sign;
	//int Rcount;                        //��ؼ��ϸ���
	int Cs;                            //���뼯de����
	int last_e;
	int IsHS();
	int Upper_Bound;
	void Init_sign(element2* e);
	void AddMember(int x,element2* e);
	CString Show();
	int SubSet(enumSetNode2 & right);   //�ü����Ƿ���right���Ӽ�
	enumSetNode2(int Count);
	enumSetNode2(enumSetNode2& esn);
};
#pragma pack()
enumSetNode2::enumSetNode2(int Count)
{
	bitVector=new int[DefaultSize];
	for(int i=0;i<DefaultSize;i++)
		bitVector[i]=0;
    Cs=Count;
	next=0;
    sign=new NYH_SE();
	sign->AddMember(Cs);
	last_e=-1;
	Upper_Bound=DefaultSize-1;
}
enumSetNode2::enumSetNode2(enumSetNode2& esn)
{
	bitVector=new int[DefaultSize];
	for(int i=0;i<DefaultSize;i++)
		bitVector[i]=esn.bitVector[i];
	next=0;
	Cs=esn.Cs;
    sign=new NYH_SE(* (esn.sign));
	last_e=esn.last_e;
	Upper_Bound=esn.Upper_Bound;
}
void enumSetNode2::Init_sign(element2* e)
{
	Node2 *p=sign->head;
	while(p!=0){
		if(e->Max[p->Value]<Upper_Bound)
			Upper_Bound=e->Max[p->Value];
		p=p->next;
	}
}
int enumSetNode2::SubSet(enumSetNode2 & right)
{
	for(int i=0;i<DefaultSize;i++)
		if(bitVector[i]&&!right.bitVector[i])return 0;
	return 1;
}
void enumSetNode2::AddMember(int x,element2* e)
{
	bitVector[x]=1;
	int i,m=0;
	for(i=0;i<Cs;i++)
	{
		if(e->pn[x][i])
		{
			sign->DeleteMember(i);
		}
	}
	last_e=x;
	Upper_Bound=DefaultSize-1;
	Node2 *p=sign->head;
	while(p!=0)
	{
		if(e->Max[p->Value]<Upper_Bound)
			Upper_Bound=e->Max[p->Value];
		p=p->next;
	}
}

int enumSetNode2::IsHS()
{
	if(sign->head==0)
	{
		return 1;
	}
    return 0;
}
CString enumSetNode2::Show()
{
	CString s="";
	CString s0;
	for(int i=0;i<DefaultSize;i++)
		if(bitVector[i])
		{
			s0.Empty();
			s0.Format("%d ",i);
			s+=s0;
		};
		return s;
}
#pragma pack(1)
class enumSetList2{
public:
	enumSetNode2* head;
	enumSetNode2* rear;
	enumSetList2();
	int IsEmpty();
	void AddRear_Node(enumSetNode2* eSN);
    enumSetNode2* DelHead();
};
#pragma pack()
enumSetList2::enumSetList2()
{
	head=0;
	rear=0;
}
int enumSetList2::IsEmpty()
{
	if(head==0)
		return 1;
	else
		return 0;
}
void enumSetList2::AddRear_Node(enumSetNode2* eSN)
{
	if(rear==0)
	{
		head=eSN;
		rear=eSN;
		rear->next=0;
	}
	else
	{
		rear->next=eSN;
		rear=rear->next;
		rear->next=0;
	}
}
enumSetNode2* enumSetList2::DelHead()
{
	if(head==0)
		return 0;
	else
	{
		enumSetNode2* p;
		p=head;
		head=head->next;
		if(head==0)
			rear=0;
		p->next=0;
		return p;
	}
}
#pragma pack(1)
class ResultList2{
public:
	enumSetNode2* R_link;
	CList<CString,CString> se2_list;
	ResultList2();
	int Add_Rset(enumSetNode2* esn);
	void Show_All();
};
#pragma pack()
ResultList2::ResultList2()
{
	R_link=0;
}
void ResultList2::Show_All()
{
	enumSetNode2* p;
	se2_list.RemoveAll();
	for(p=R_link;p!=0;p=p->next)
	{
		se2_list.AddHead(p->Show());
	}
}
int ResultList2::Add_Rset(enumSetNode2* esn){
	if(R_link==0)                      //��Ϊ��
	{
		R_link=esn;
		esn->next=0;
		return 1;
	}
	else
	{
		enumSetNode2* p;	
		for(p=R_link;p->next!=0;p=p->next)
		{
			if(p->SubSet(*esn))        //��������иü��ϵ��Ӽ�
				return 0;
		}
		if(p->SubSet(*esn))
		{
			return 0;
		}
		p->next=esn;
		esn->next=0;
        return 1;
	}
}

void SE_HS(input_list2* il,ResultList2* pHS,int& node_count){


	int i;
	//node_count=0;
	enumSetNode2* p,*q;
	element2 *e=new element2(il);

	enumSetList2* eSL=new enumSetList2();
	enumSetList2* nEL=new enumSetList2();

	p=new enumSetNode2(il->Count);
	node_count++;
	p->Init_sign(e);
	nEL->AddRear_Node(p);
	while(nEL->head!=0)
	{
		for(p=nEL->DelHead();p!=0;p=nEL->DelHead())
		{

			for(i=p->last_e+1;i<=p->Upper_Bound;i++)
			{
				
				if(il->exist[i])
				{
					q=new enumSetNode2(*p);
					node_count++;
					q->AddMember(i,e);
					//q->Init_sign(e);
					eSL->AddRear_Node(q);
				}
			}
			delete p;
		}	
		for(p=eSL->DelHead();p!=0;p=eSL->DelHead())
		{
			if(p->IsHS())              //hitting set
            {
				pHS->Add_Rset(p);      //��������
            }
			else
			{
				if(p->sign->head==0)//�����������к�����ĩԪ��
				{
					delete p;
				}
				else                   //������չ
				{
					nEL->AddRear_Node(p);
				}
			}
		}

	}	

}

/////////////////////////////////////////////////////////////////////////////////////
class S_nodeb;
class input_listb;
class elementb;
class Nodeb;
class NYH_SEd;
class Nodec;
class NYH_SEt;
class enumSetNodec;
class S_nodeb                           //�������Ľڵ�
{
public:
	int* bitVector;
	S_nodeb* next;
	S_nodeb();
	S_nodeb(char* str);
	S_nodeb(Nodec* nd);
	int Max;
	void Show();
};

class input_listb
{
public:
	friend class NYH_SEt;
	int Count;                         //��ͻ���ĸ���
	input_listb();
	input_listb(NYH_SEt* listn);
	S_nodeb* s_point;
	int last;                          //���һ�������Ԫ��
	int * exist;                       //�����Ԫ�� �������Ĵ���
	void Insert_S(char* str);

void Insert_S(S_nodeb *q);

	void ShowAll();
};
class elementb
{
public:
	int* *pn;                          //ÿ��Ԫ������������Ĺ���
	int Cs;                            //��������ĸ���
	elementb(int Count);
	elementb(input_listb* il);
	int* Max;
};

class Nodeb{
public:
	Nodeb(int x);
	Nodeb(Nodeb &n);
	int Value;
	Nodeb* next;
};
class NYH_SEd{
public:
	NYH_SEd();
	NYH_SEd(NYH_SEd &li);
	Nodeb* head;
	void AddMember(int Size);
	int DeleteMember(int x);
	int mem_count;
};

class Nodec
{
public:
	Nodec();
	int set_No;                        //��ǰ�ڵ������ĸ����뼯������
	int* bitVector;
	Nodec* next;
	void ShowMember();
	void Init_Set(int no,const elementb* e);
};
class NYH_SEt
{
public:
	Nodec* head;
	Nodec* rear;
    void AddRear(int n,elementb* e);
	void AddRear(Nodec* node_p);
	Nodec* DelHead();
	NYH_SEt();
	int count_s;
	void ShowAllM();
};

class enumSetNodeb
{
public:
	int* bitVector;
	enumSetNodeb* next;
	NYH_SEd * sign;
	int Cs;                            //���뼯de����
	int last_e;
	int IsHS();
	int Upper_Bound;
	void Init_sign(elementb* e);
	void AddMember(int x,elementb* e);
	CString Show();
	int SubSet(enumSetNodeb & right);   //�ü����Ƿ���right���Ӽ�
	enumSetNodeb(int Count);
	enumSetNodeb(enumSetNodeb& esn);
	int CanBeD(elementb *e,NYH_SEt *&list_s1,NYH_SEt*& list_s2);
};

class enumSetListb{
public:
	enumSetNodeb* head;
	enumSetNodeb* rear;
	enumSetListb();
	int IsEmpty();
	void AddRear_Node(enumSetNodeb* eSN);
    enumSetNodeb* DelHead();
	//void Show_All();
};

class ResultListb{
public:
	enumSetNodeb* R_link;
	CList<CString,CString> seb_list;
	ResultListb();
	int Add_Rset(enumSetNodeb* esn);
	void Show_All();
};
/////////////////////////////////////////////////////////////////
S_nodeb::S_nodeb(Nodec* nd)
{
    bitVector=new int[DefaultSize];
	for(int i=0;i<DefaultSize;i++)
	{
		bitVector[i]=nd->bitVector[i];
		if(nd->bitVector[i])		 
			Max=i;
	}
	next=0;
}
S_nodeb::S_nodeb(){
	bitVector=new int [DefaultSize];
	for(int i=0;i<DefaultSize;i++) bitVector[i]=0;
	next=0;
	Max=0;
}
S_nodeb::S_nodeb(char* str){
	bitVector=new int [DefaultSize];
	for(int i=0;i<DefaultSize;i++) bitVector[i]=0;
	next=0;
	int x;
    istrstream ss(str);                //������
	while(!ss.eof())                   //��������
	{
		ss>>x;                         //ȡһ������
        assert(x>=0 && x<DefaultSize);
		if(x>Max)
		{
			Max=x;
		}
	    bitVector[x]=1;
	}
}
void S_nodeb::Show()
{
	for(int i=0;i<DefaultSize;i++)
		if(bitVector[i])
		{
			cout<<i<<" ";
		}
		cout<<endl;
}

input_listb::input_listb(NYH_SEt* listn)
{
	Nodec* p=listn->head;
	S_nodeb* q;
	s_point=0;
	S_nodeb *rear=0;
	last=-1;
	Count=0;
	exist=new int[DefaultSize];
	for(int i=0;i<DefaultSize;i++)
		exist[i]=0;
	while(p!=0)
	{
		q=new S_nodeb(p);
		Count++;
		for(i=0;i<DefaultSize;i++)
		{
			exist[i]=q->bitVector[i]+exist[i];
		}
		if(q->Max>last)
			last=q->Max;
		if(s_point==0)
		{
			s_point=q;
			rear=q;
		}
		else
		{
			rear->next=q;
			rear=q;
		}
		p=p->next;
	}
}
input_listb::input_listb()
{
	Count=0;
	s_point=0;
	last=-1;
	exist=new int[DefaultSize];
	for(int i=0;i<DefaultSize;i++)
	{
		exist[i]=0;
	}
}
void input_listb::Insert_S(char* str)
{
	S_nodeb *p,*q;
    q=new S_nodeb(str);
	if(s_point==0)
	{
		s_point=q;
	}
	else
	{
		p=s_point;
		while(p->next!=0)
		{
			p=p->next;
		}
		p->next=q;
	}
	Count++;
	for(int i=0;i<DefaultSize;i++)
		exist[i]+=q->bitVector[i];
	for(i=last+1;i<DefaultSize;i++)
	{
		if(q->bitVector[i])
		{
			last=i;
		}
	}
}

void input_listb::Insert_S(	S_nodeb *q)
{
	S_nodeb *p;
 //   q=new S_nodeb(str);
	if(s_point==0)
	{
		s_point=q;
	}
	else
	{
		p=s_point;
		while(p->next!=0)
		{
			p=p->next;
		}
		p->next=q;
	}
	Count++;
	for(int i=0;i<DefaultSize;i++)
		exist[i]+=q->bitVector[i];
	for(i=last+1;i<DefaultSize;i++)
	{
		if(q->bitVector[i])
		{
			last=i;
		}
	}
}

void input_listb::ShowAll()
{
	S_nodeb *p;
	p=s_point;
	while(p!=0)
	{
		p->Show();
		p=p->next;
	}
}

Nodeb::Nodeb(int x){
	Value=x;
	next=0;
}
Nodeb::Nodeb(Nodeb &n)
{
	Value=n.Value;
	next=0;
}

NYH_SEd::NYH_SEd(){
	head=0;
	mem_count=0;
}

NYH_SEd::NYH_SEd(NYH_SEd &li)
{
	Nodeb *p,*q,*r;
	q=li.head;
	if(q!=0)
	{
		p=new Nodeb(*q);
	    head=p;
		r=head;
		while(q->next!=0)
		{
			p=new Nodeb(*(q->next));
			r->next=p;
			r=p;
			q=q->next;
		}
		mem_count=li.mem_count;
	}
	else
	{
		head=0;
	}
}
void NYH_SEd::AddMember(int Size)
{
	if(Size>0)
	{	
		Nodeb* p,*q;
	    q=0;
	    for(int i=Size-1;i>=0;i--)
		{
			p=new Nodeb(i);
			p->next=q;
			q=p;
		}
		head=q;
	}
	mem_count++;
}
int NYH_SEd::DeleteMember(int x){
	Nodeb *p,*q;
	p=head;
	if(p==0)
	{
		return 0;
	}
	else
	{
		if(p->Value==x)
		{
			head=p->next;
			delete p;
			mem_count--;
			return 1;
		}
		else
		{
			while(p->next!=0)
			{
				if(p->next->Value==x)
				{
					q=p->next;
					p->next=q->next;
					delete q;
					mem_count--;
					return 1;
				}
				else
				{
					if(p->next->Value<x)
					{
						p=p->next;
					}
					else
					{
						return 0;
					}
				}
			}
		}
		return 0;
	}
}

void Nodec::ShowMember()
{
	for(int i=0;i<DefaultSize;i++)
		if(bitVector[i])
		{
			cout<<i<<" ";
		}
		cout<<endl;
}
Nodec::Nodec()
{
	set_No=-1;
	bitVector=new int[DefaultSize];
	next=0;
}
void Nodec::Init_Set(int no,const elementb* e)
{
	set_No=no;
	for(int i=0;i<DefaultSize;i++)
		bitVector[i]=e->pn[i][no];
	next=0;
}

NYH_SEt::NYH_SEt()
{
	head=0;
	rear=0;
	count_s=0;
}
void NYH_SEt::ShowAllM()
{
	Nodec* p;
	p=head;
	while(p!=0)
	{
		p->ShowMember();
		p=p->next;
	}
}
void NYH_SEt::AddRear(int n,elementb* e)
{
	Nodec* p=new Nodec();
	p->Init_Set(n,e);
	if(head==0)
	{
		head=p;
		rear=p;
	}
	else
	{
		rear->next=p;
		rear=p;
	}
	count_s++;
}
void NYH_SEt::AddRear(Nodec* node_p)
{
	if(head==0)
	{
		head=node_p;
		rear=node_p;
	}
	else
	{
		rear->next=node_p;
		rear=node_p;
	}
	count_s++;
}
Nodec* NYH_SEt::DelHead()
{
	if(head==0)
		return 0;
	else
	{
		Nodec* p=head;
		head=head->next;
		if(head==0)
		{
			rear=0;
		}
		count_s--;
		p->next=0;
		return p;
	}
}

enumSetNodeb::enumSetNodeb(int Count)
{
	bitVector=new int[DefaultSize];
	for(int i=0;i<DefaultSize;i++)
		bitVector[i]=0;
    Cs=Count;
	next=0;
    sign=new NYH_SEd();
	sign->AddMember(Cs);
	last_e=-1;
	Upper_Bound=DefaultSize-1;
}
elementb::elementb(int Count){
	int i,j;
	Cs=Count;
	pn=new int*[DefaultSize];
	for(i=0;i<DefaultSize;i++)
		pn[i]=new int[Count];
	Max=new int[Count];
	for(i=0;i<DefaultSize;i++)
		for(j=0;j<Count;j++)
			pn[i][j]=0;
	for(j=0;j<Count;j++)
		Max[j]=DefaultSize-1;
}
elementb::elementb(input_listb* il){
	int i,j;
	Cs=il->Count;
	pn=new int*[DefaultSize];
	for(i=0;i<DefaultSize;i++)
		pn[i]=new int[Cs];
	Max=new int[Cs];
    S_nodeb* p;
	for(p=il->s_point,i=0;p!=0;p=p->next,i++)
	{
		for(j=0;j<DefaultSize;j++)
		{
			pn[j][i]=p->bitVector[j];
		}
		Max[i]=p->Max;
	}
}
enumSetNodeb::enumSetNodeb(enumSetNodeb& esn)
{
	bitVector=new int[DefaultSize];
	for(int i=0;i<DefaultSize;i++)
		bitVector[i]=esn.bitVector[i];
	next=0;
	Cs=esn.Cs;
    sign=new NYH_SEd(* (esn.sign));
	last_e=esn.last_e;
	Upper_Bound=esn.Upper_Bound;
}
void enumSetNodeb::Init_sign(elementb* e)
{
	Nodeb *p=sign->head;
	while(p!=0){
		if(e->Max[p->Value]<Upper_Bound)
			Upper_Bound=e->Max[p->Value];
		p=p->next;
	}
}
int enumSetNodeb::CanBeD(elementb *e,NYH_SEt *&list_s1,NYH_SEt* &list_s2)
{
	list_s1=new NYH_SEt();
	Nodeb* p=sign->head;
    while(p!=0)
	{
		list_s1->AddRear(p->Value,e);
		p=p->next;
	}

	if(list_s1->count_s!=0)
	{
		int* rec=new int[DefaultSize];     //��ʱ��¼����һ��
		Nodec* pc=list_s1->head;
		for(int j=0;j<DefaultSize;j++)
			rec[j]=e->pn[j][pc->set_No];
		list_s2=new NYH_SEt();         
		int c2=1;                         //s2�нڵ����c2
		for(int k=0;k<c2;k++)
		{
			int c=list_s1->count_s;       //s1�нڵ����c
			for(int i=0;i<c;i++)
			{	
				pc=list_s1->DelHead();
			    for(j=0;j<DefaultSize;j++)
				{
					if(rec[j]&&pc->bitVector[j])
					break;
				}
				if(j<DefaultSize)
				{
					for(j=0;j<DefaultSize;j++)
						rec[j]=rec[j]||(e->pn[j][pc->set_No]);
					list_s2->AddRear(pc);

				}
			    else
				{
					list_s1->AddRear(pc);
				}
			}	
			c2=list_s2->count_s;
		}
		if(list_s1->head==0)
		{
			return 0;
		}
		else
		{
			return 1;
		}
	}
	else
	{
		return 0;
	}
}

int enumSetNodeb::SubSet(enumSetNodeb & right)
{
	for(int i=0;i<DefaultSize;i++)
		if(bitVector[i]&&!right.bitVector[i])return 0;
	return 1;
}
void enumSetNodeb::AddMember(int x,elementb* e)
{
	bitVector[x]=1;
	int i,m=0;
	for(i=0;i<Cs;i++)
	{
		if(e->pn[x][i])
		{
			sign->DeleteMember(i);
		}
	}
	last_e=x;
	Upper_Bound=DefaultSize-1;
	Nodeb *p=sign->head;
	while(p!=0){
		if(e->Max[p->Value]<Upper_Bound)
			Upper_Bound=e->Max[p->Value];
		p=p->next;
	}
}

int enumSetNodeb::IsHS()
{
	if(sign->head==0)
	{
		return 1;
	}
    return 0;
}
CString enumSetNodeb::Show()
{
	CString s="";
	CString s0;
	for(int i=0;i<DefaultSize;i++)
		if(bitVector[i])
		{
			s0.Empty();
			s0.Format("%d ",i);
			s+=s0;
		};
		return s;
}

enumSetListb::enumSetListb()
{
	head=0;
	rear=0;
}
int enumSetListb::IsEmpty()
{
	if(head==0)
		return 1;
	else
		return 0;
}
void enumSetListb::AddRear_Node(enumSetNodeb* eSN)
{
	if(rear==0)
	{
		head=eSN;
		rear=eSN;
		rear->next=0;
	}
	else
	{
		rear->next=eSN;
		rear=rear->next;
		rear->next=0;
	}
}
enumSetNodeb* enumSetListb::DelHead()
{
	if(head==0)
	{
		return 0;
	}
	else
	{
		enumSetNodeb* p;
		p=head;
		head=head->next;
		if(head==0)
		{
			rear=0;
		}
		return p;
	}
}

ResultListb::ResultListb()
{
	R_link=0;
}
void ResultListb::Show_All()
{
	enumSetNodeb* p;
	seb_list.RemoveAll();
	for(p=R_link;p!=0;p=p->next)
	{
		seb_list.AddHead(p->Show());
	}
}

int ResultListb::Add_Rset(enumSetNodeb* esn){
	enumSetNodeb *q,*r,*t;
	enumSetNodeb *e=new enumSetNodeb(*esn);
	if(R_link==0)                      //��Ϊ��
	{
		R_link=e;
		return 1;
	}
	q=R_link;
	r=q->next;
	while(r!=0)
	{
		if(r->SubSet(*e))
		{
			delete e;
			return 0;
		}
		if(e->SubSet(*r))
		{
			q->next=r->next;
			t=r;
			r=r->next;
			delete t;
			continue;
		}
		q=q->next;
		r=q->next;
	}
	r=R_link;
	if (r->SubSet(*e))
	{
		return 0;
	}
	if(e->SubSet(*r))
	{
		R_link=R_link->next;
		t=r;
		r=r->next;
		delete t;
	}
	if(R_link==0)
	{
		R_link=e;
		return 1;
	}
	else
	{
		q->next=e;
		return 1;
	}
}

void SEHSD(input_listb* &il,ResultListb* &pHS,int& node_count)
{
	int i;
	enumSetNodeb* p,*q;
	elementb *e=new elementb(il);

	enumSetListb* eSL=new enumSetListb();
	enumSetListb* nEL=new enumSetListb();
	
	p=new enumSetNodeb(il->Count);
	node_count++;
	p->Init_sign(e);
	eSL->AddRear_Node(p);

	while(eSL->head!=0)
	{


		for(p=eSL->DelHead();p!=0;p=eSL->DelHead())
		{
			if(p->IsHS())              //hitting set
            {
				pHS->Add_Rset(p);      //��������
            }
			else
			{
				NYH_SEt *list_s1,*list_s2;
				list_s1=0;
				list_s2=0;
				if(p->CanBeD(e,list_s1,list_s2))
				{
					input_listb* il_1=new input_listb(list_s1);
					input_listb* il_2=new input_listb(list_s2);

					ResultListb* ol_1=new ResultListb();
					ResultListb* ol_2=new ResultListb();
					SEHSD(il_1,ol_1,node_count);
					SEHSD(il_2,ol_2,node_count);

					enumSetNodeb *p1,*p2,*p3;
					
					for(p1=ol_1->R_link;p1!=0;p1=p1->next)
					{
						for(p2=ol_2->R_link;p2!=0;p2=p2->next)
						{
							p3=new enumSetNodeb(*p);
							node_count++;
							for(int i=0;i<DefaultSize;i++)
							{
								p3->bitVector[i]=p3->bitVector[i]||p1->bitVector[i];
								p3->bitVector[i]=p3->bitVector[i]||p2->bitVector[i];
							}
							pHS->Add_Rset(p3);
						}
					}
				}
				else
				{
				    nEL->AddRear_Node(p);
				}
			}
		}
		for(p=nEL->DelHead();p!=0;p=nEL->DelHead())
		{
			for(i=p->last_e+1;i<=p->Upper_Bound;i++)
			{
				if(il->exist[i])
				{
					q=new enumSetNodeb(*p);
					node_count++;
					q->AddMember(i,e);

					eSL->AddRear_Node(q);
				}
			}
			delete p;
		}
	}
}

